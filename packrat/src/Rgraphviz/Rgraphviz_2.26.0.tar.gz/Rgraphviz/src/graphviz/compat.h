#ifndef COMPAT_H
#define COMPAT_H
#ifdef HAVE_CONFIG_H
#include "config.h"
/*
#ifndef HAVE_STRCASECMP
extern int strcasecmp(const char*, const char*);
#endif
#ifndef HAVE_STRNCASECMP
extern int strncasecmp(const char*, const char*, unsigned int);
#endif
*/
#endif
#endif
